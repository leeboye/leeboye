$(function () {
    $('.slide').slick({

        prevArrow: $('.prev'),
        nextArrow: $('.next'),
    });
})